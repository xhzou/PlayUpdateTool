package com.pp100.frame;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import com.pp100.utils.FileUtil;
import com.pp100.utils.PropertiesUtil;

/**
 * @author xhzou
 * @version 2.0
 * @created 2015年10月25日 下午4:00:53
 */
public class DropDragFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private JButton btnClose = new JButton("C 关闭");
    private JButton btnGenerate = new JButton("G 生成");
    private JTextField txtCodePath = new JTextField();
    private JTextField txtPlayPath = new JTextField();
    private JTextArea areaFileList = new JTextArea();
    private JTextArea areaLogInfo = new JTextArea();
    private JCheckBox cbxOnlyJava = new JCheckBox("编译所有JAVA");
    private JLabel lblVersion = new JLabel("2016.01 ShenZhen China zxiaohui@vip.qq.com");
    private boolean isCMDMode = false;

    String specifyJava = "";
    String specifyHtml = "";
    String specifyOther = "";
    
    String pathSeparator = System.getProperty("path.separator");

    public DropDragFrame() {
        initFrameInfo();
        initControl();
        initConfValue();
        bindEvent();
    }

    /**
     * 仅用于 CMD 模式
     * 
     * @param codePath
     * @param playPath
     */
    public DropDragFrame(boolean _isCMDMode) {
        this();
        isCMDMode = _isCMDMode;
        
        try {
            getCMDAllFiles();
        } catch (IOException e) {
            println(e.getMessage());
            e.printStackTrace();
            return;
        }

        // 启动编译 准备好局部更新包
        createVersionFile();
    }
    
    private void getCMDAllFiles() throws FileNotFoundException, IOException {
        //String strHtml=" app/views/supervisor/webContentManager/Message/sendMessageInit.html |  89 ++++++++++++++++++++++++++++++++++++++++++++++++++++++-----------------------------------";
        String regex = PropertiesUtil.getProperties("regex", "^\\s(app/|conf/|public/){1}.*\\s+\\|\\s+(\\d+\\s+\\++\\-*|Bin)\\s*$");
        String replace_regex = PropertiesUtil.getProperties("replace_regex", "\\|(\\d+\\s+\\++\\-*|Bin)\\s*");
        
        String tmpFilePath=System.getProperty("java.io.tmpdir") + "/changelist.log";
        File file = new File(tmpFilePath);
        if (!file.exists()) {
            System.out.println("file not exits");
            throw new FileNotFoundException("specify "+tmpFilePath+" file is not exists...");
        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
        StringBuffer bufFiles = new StringBuffer();
        String data=null;
        while ((data = reader.readLine()) != null) {
            if(data.matches(regex)){
                data = data.replaceAll("\\s", "").replaceAll(replace_regex, "");
                bufFiles.append("/").append(data).append("\n");
            }
        }
        reader.close();
        println("update file list: \n"+bufFiles);
        if(bufFiles.toString().isEmpty()){
            throw new IOException("未找到修改或新增文件.详情请查看  " + tmpFilePath);
        }   
        areaFileList.setText(bufFiles.toString());
    }
    
/*    
 *  用于 svn 模式，hg 在此方面有差异
 * private void getCMDAllFiles() throws FileNotFoundException, IOException {
        
        String tmpFilePath=System.getProperty("java.io.tmpdir") + "/changelist.log";
        File file = new File(tmpFilePath);
        if (!file.exists()) {
            throw new FileNotFoundException("specify "+tmpFilePath+" file is not exists...");
        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
        StringBuffer bufFiles = new StringBuffer();
        String strA="A       ";
        String strM="M       ";
        String data=null;
        while ((data = reader.readLine()) != null) {
            if (data.startsWith(strA) || data.startsWith(strM)) {
                data = data.replace(strA, "").replace(strM, "").replace("\\", "/");
                bufFiles.append("/").append(data).append("\n");
            }
        }
        reader.close();
        println("update file list: "+bufFiles);
        if(bufFiles.toString().isEmpty()){
            throw new IOException("未找到修改或新增文件.详情请查看  " + tmpFilePath);
        }
        areaFileList.setText(bufFiles.toString());
    }
*/
    private void initConfValue() {
        // txtCodePath.setText("D:/develop/workspace/framework_play/framework_play");
        txtCodePath.setText(PropertiesUtil.getProperties("code_path", "D:/code/p2p/trunk/code/com.shovesoft.sp2p"));
        txtPlayPath.setText(PropertiesUtil.getProperties("play_path", "D:/develop/java/play_framework/play-1.2.7"));
        println("点击生成后将开始打包，耗时较久，请耐心等候。");
    }

    /**
     * 初始化控件信息
     * 
     * @author xhzou
     * @version 1.0
     * @created 2015年10月25日 下午5:42:38
     */
    private void initControl() {
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBorder(BorderFactory.createTitledBorder("文件列表"));
        scrollPane.setViewportView(areaFileList);
        areaFileList.setColumns(70);
        areaFileList.setRows(16);

        areaLogInfo.setColumns(70);
        areaLogInfo.setRows(8);
        areaLogInfo.setEditable(false);
        // textArea.setEditable(false);

        btnClose.setMnemonic('C');
        btnGenerate.setMnemonic('G');

        txtCodePath.setPreferredSize(new Dimension(250, 20));
        txtPlayPath.setPreferredSize(new Dimension(350, 20));
        lblVersion.setPreferredSize(new Dimension(650, 20));

        JPanel panel = new JPanel();

        panel.add(new JLabel("代码路径："));
        panel.add(txtCodePath);
        panel.add(new JLabel("Play路径："));
        panel.add(txtPlayPath);

        JPanel panelLog = new JPanel();
        panelLog.setBorder(BorderFactory.createTitledBorder("日志信息"));
        panelLog.add(areaLogInfo);

        panel.add(scrollPane);
        panel.add(panelLog);
        // panel.add(cbxOnlyJava);
        panel.add(btnGenerate);
        panel.add(btnClose);
        panel.add(lblVersion);

        this.add(panel);
    }

    /**
     * 初始化窗体信息
     * 
     * @author xhzou
     * @version 1.0
     * @created 2015年10月25日 下午5:42:29
     */
    private void initFrameInfo() {
        this.setTitle("Play 局部编译+局部更新包生成器 V3.4 by 邹小辉");
        this.setSize(800, 630);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        try {
            this.setIconImage(ImageIO.read(this.getClass().getResource("/images/icon.png")));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 绑定按钮事件
     * 
     * @author xhzou
     * @version 1.0
     * @created 2015年10月25日 下午5:42:16
     */
    private void bindEvent() {
        btnClose.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        btnGenerate.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                areaLogInfo.setText("");
                println("点击生成后将开始打包，耗时较久，请耐心等候。");
                createVersionFile();
            }
        });

    }

    private void createVersionFile() {
        if (isCMDMode) {
            println("正在生成更新包...");
        }
        else {
            if (areaFileList.getText().isEmpty() && !cbxOnlyJava.isSelected()) {
                println("not specify any files...");
                return;
            }
        }
        String[] specifyFiles = areaFileList.getText().split("\n");

        // 1.编译包
        initSpecifyFileClassify(specifyFiles);
        long start = System.currentTimeMillis();

        if (!specifyHtml.isEmpty() || !specifyJava.isEmpty()) {// 无指定 html java时不与 play 进行交互 20160331
            int exitCode = execCommand(getCompileCmd());

            if (0 != exitCode) {
                println("compile error... program exit.");
                return;
            }
        }

        String codePath = txtCodePath.getText().trim();
        if (cbxOnlyJava.isSelected()) {
            println("compile all java,not contains template.");
            execCommand("cmd /c start " + codePath + "/precompiled");
            return;
        }

        // 2.准备局部更新包文件
        File applicationFile = copyCompileFiles(specifyFiles, codePath);

        // 3.分完类后打开此 tmp 路径 ，供手工打包上传，并执行自动化部署脚本
        long seconds = (System.currentTimeMillis() - start) / 1000;
        if (isCMDMode) {
            println("update package path=" + applicationFile.getAbsolutePath());
        }
        else {
            execCommand("cmd /c start " + applicationFile.getAbsolutePath());
        }
        println("success, use time=" + seconds + "s");
    }

    /**
     * 准备局部更新包文件
     * 
     * @author xhzou
     * @version 1.0
     * @created 2016年1月24日 下午2:03:09
     * @param specifyFiles 指定要局部打包的文件数组
     * @param codePath 代码路径
     * @return
     */
    private File copyCompileFiles(String[] specifyFiles, String codePath) {
        String tmpApplicationPath = System.getProperty("java.io.tmpdir") + "/application";
        File applicationFile = new File(tmpApplicationPath);
        // 1.在 tmp 下生成 application 目录，其下有三个子目录 app precompiled public
        // 存在则删除并重新创建
        if (applicationFile.exists()) {
            FileUtil.delFile(applicationFile.getAbsolutePath());
            applicationFile.mkdir();
        }

        for (String filePath : specifyFiles) {
            if (null == filePath || filePath.isEmpty()) {
                continue;
            }
            filePath = filePath.trim().replace("\\", "/");// 去除左右空格
            File codeFile = new File(codePath + filePath);// 代码源文件
            if (!codeFile.exists() && !filePath.contains("$")) // 过滤掉 $1*.java 的情况
            {
                println("[warn]source file not exists. " + filePath);
                continue;
            }

            String path = getCompilePath(filePath);
            if (path.isEmpty()) {
                continue;
            }

            // 复制预编译后的文件
            File sFile = new File(codePath + path);// 预编译源文件
                if (!sFile.exists() || sFile.isDirectory()) {
                    println("[warn]precompiled file not exists ... " + filePath);
                    continue;
                }

            File dFile = new File(tmpApplicationPath + "/" + path);// 目标文件
            dFile.getParentFile().mkdirs();
            FileUtil.fileChannelCopy(sFile, dFile);
            // 检测是否存在内部类的 class 文件
            if (sFile.getName().contains(".class")) {
                File[] subClass = sFile.getParentFile().listFiles();
                for (File f : subClass) {
                    if (f.getName().contains(sFile.getName().replace(".class", "") + "$")) {
                        FileUtil.fileChannelCopy(f, new File(dFile.getParent() + "/" + f.getName()));
                    }
                }
            }
           

            // 复制java 或 html 源文件，只需要生成文件即可(java 或 html 文件)
            if (filePath.contains("/app/")) {
                String t = tmpApplicationPath + filePath;
                File file = new File(t);// 目标文件
                file.getParentFile().mkdirs();
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    println(e.getMessage());
                }
            }
        }
        return applicationFile;
    }

    private int execCommand(String openCmd) {
        int exitCode = -1;
        try {
            Process process = Runtime.getRuntime().exec(openCmd);
            exitCode = process.waitFor();
        } catch (Exception ex) {
            println(ex.getMessage());
        }
        return exitCode;
    }

    /**
     * 初始指定文件的分类
     * 
     * @param specifyFiles
     */
    private void initSpecifyFileClassify(String[] specifyFiles) {
        if (null == specifyFiles) {
            return;
        }
        StringBuffer bufHtml = new StringBuffer();
        StringBuffer bufJava = new StringBuffer();
        StringBuffer bufOther = new StringBuffer();

        for (String s : specifyFiles) {
            if (s.endsWith(".java")) {
                bufJava.append(s).append(pathSeparator);
            }
            else if (s.endsWith(".html") || s.endsWith(".control")) {
                bufHtml.append(s).append(pathSeparator);
            }
            else {
                bufOther.append(s).append(pathSeparator);
            }
        }

        specifyHtml = bufHtml.toString();
        specifyJava = bufJava.toString();
        specifyOther = bufOther.toString();
    }

    private String getCompileCmd() {
        String javaHome = System.getProperty("java.home");
        String applicationPath = txtCodePath.getText().trim();
        String playPath = txtPlayPath.getText().trim();

        StringBuffer cmdBuf = new StringBuffer();
        cmdBuf.append(javaHome + "/bin/java");
        cmdBuf.append(" -javaagent:" + playPath + "/framework/play-1.2.7.jar");
        cmdBuf.append(" -Dprecompile=yes -XX:-UseSplitVerifier -Dfile.encoding=utf-8 -XX:CompileCommand=exclude,jregex/Pretokenizer,next");
        cmdBuf.append(" -Xdebug -Xrunjdwp:transport=dt_socket,address=0,server=y,suspend=n");
        cmdBuf.append(" -Xms256m -Xmx512m -XX:PermSize=256M -XX:MaxPermSize=512m");
        cmdBuf.append(" -Dplay.debug=yes");
        cmdBuf.append(" -classpath " + applicationPath + "/conf").append(pathSeparator);
        cmdBuf.append(playPath + "/framework/play-1.2.7.jar").append(pathSeparator);
        cmdBuf.append(applicationPath + "/lib/*").append(pathSeparator);
        cmdBuf.append(playPath + "/framework/lib/*").append(pathSeparator);
        cmdBuf.append(" -Dapplication.path=" + applicationPath);
        cmdBuf.append(" -Dplay.id=''");
        cmdBuf.append(" -DspecifyJava=" + specifyJava);
        cmdBuf.append(" -DspecifyHtml=" + specifyHtml);
        cmdBuf.append(" -DonlyCompileJava=" + (cbxOnlyJava.isSelected() ? "yes" : ""));
        cmdBuf.append(" play.server.Server > " + System.getProperty("java.io.tmpdir") + "/compile_info.log");

//        println(cmdBuf);
        return cmdBuf.toString();
    }
    private void println(StringBuffer msg) {
        println(msg.toString());
    }
    private void println(String msg) {
        if(isCMDMode){
            System.out.println(msg);
        }else{
            areaLogInfo.append(msg + "\n");
        }
    }

    /**
     * 获取编译后文件路径
     * 
     * @author xhzou
     * @version 1.0
     * @created 2016年1月24日 下午1:57:47
     * @param filePath
     * @return
     */
    private String getCompilePath(String filePath) {
        String path = "";
        boolean isFtlFile=filePath.endsWith(".ftl");
        
        if (filePath.contains("/app/views")) {
            path = "/precompiled/templates/" + filePath;
        } else if (filePath.contains("/app/") && !isFtlFile) {
            path = "/precompiled/java/" + filePath;
            path = path.replace(".java", ".class").replaceFirst("/app/", "");
        } else if (filePath.contains("/public") || filePath.contains("/conf") || isFtlFile) {
            path = filePath;
        } else {
            println(" source file not support... " + filePath);
        }

        return path;
    }
}
