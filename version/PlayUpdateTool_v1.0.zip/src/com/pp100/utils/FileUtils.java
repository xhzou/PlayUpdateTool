package com.pp100.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

/**
 * @author xhzou
 * @version 2.0
 * @created 2015年10月25日 下午5:21:00
 */
public class FileUtils
{
    /**
     * 使用文件通道的方式复制文件
     * 
     * @author xhzou
     * @version 1.0
     * @created 2015年10月25日 下午5:21:20
     * @param s 源文件
     * @param d 复制到的新文件
     */
    public static void fileChannelCopy(File s, File d)
    {

        FileInputStream fi = null;
        FileOutputStream fo = null;
        FileChannel in = null;
        FileChannel out = null;
        try
        {

            fi = new FileInputStream(s);
            fo = new FileOutputStream(d);
            in = fi.getChannel();// 得到对应的文件通道
            out = fo.getChannel();// 得到对应的文件通道
            in.transferTo(0, in.size(), out);// 连接两个通道，并且从in通道读取，然后写入out通道

        } catch (IOException e)
        {
            e.printStackTrace();

        } finally
        {
            try
            {

                fi.close();
                in.close();
                fo.close();
                out.close();

            } catch (IOException e)
            {
                e.printStackTrace();

            }

        }

    }

    /**
     * 递归删除文件及文件夹
     * 
     * @author xhzou
     * @version 1.0
     * @created 2015年10月25日 下午5:37:48
     * @param path
     */
    public static void delFile(String path)
    {
        File f = new File(path);
        if (f.exists())
        {
            if (f.isDirectory())
            {
                File[] fs = f.listFiles();
                if (fs.length > 0)
                {
                    for (File file : fs)
                    {
                        delFile(file.getAbsolutePath());
                    }
                }
            }
            f.delete();
        }
    }
}
