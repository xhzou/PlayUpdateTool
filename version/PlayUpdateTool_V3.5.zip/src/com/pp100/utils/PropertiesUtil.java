package com.pp100.utils;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertiesUtil
{
    private static Properties prop;

    public static String getProperties(String key, String def)
    {
        if (null == prop)
        {
            setProp();
        }
        String value = prop.get(key) + "";
        if (value.isEmpty() || "null".equals(value))
        {
            return def;
        }
        return value;
    }

    private static void setProp()
    {
        if (prop == null)
        {
            try
            {
                prop = new Properties();
                prop.load(new FileInputStream("config.conf"));

            } catch (Exception e)
            {
            }
        }
    }

}
