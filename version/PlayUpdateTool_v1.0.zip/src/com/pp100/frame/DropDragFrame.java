package com.pp100.frame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

import com.pp100.utils.FileUtils;

/**
 * @author xhzou
 * @version 2.0
 * @created 2015年10月25日 下午4:00:53
 */
public class DropDragFrame extends JFrame
{
    private static final long serialVersionUID = 1L;
    private JButton btnClear = new JButton("C 清空列表");
    private JButton btnGenerate = new JButton("G 生成更新包");
    private JTextArea textArea = new DropDragSupportTextArea();

    public DropDragFrame()
    {
        initFrameInfo();
        initControl();
        bindEvent();
    }

    /**
     * 初始化控件信息
     * @author xhzou
     * @version 1.0
     * @created 2015年10月25日 下午5:42:38
     */
    private void initControl()
    {
        JPanel panel = new JPanel();

        JScrollPane jsp = new JScrollPane();
        jsp.setViewportView(textArea);
        textArea.setColumns(70);
        textArea.setRows(20);
        textArea.setEditable(false);

        btnClear.setMnemonic('C');
        btnGenerate.setMnemonic('G');

        panel.add(jsp);
        panel.add(btnClear);
        panel.add(btnGenerate);

        this.add(panel);
    }

    /**
     * 初始化窗体信息
     * @author xhzou
     * @version 1.0
     * @created 2015年10月25日 下午5:42:29
     */
    private void initFrameInfo()
    {
        this.setTitle("Play 局部更新包生成器 V1.0 by 邹小辉");
        this.setSize(800, 430);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        
        try
        {
            this.setIconImage(ImageIO.read(this.getClass().getResource("/images/icon.png")));
        } catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    /**
     * 绑定按钮事件
     * @author xhzou
     * @version 1.0
     * @created 2015年10月25日 下午5:42:16
     */
    private void bindEvent()
    {
        btnClear.addActionListener(new ActionListener()
        {

            @Override
            public void actionPerformed(ActionEvent e)
            {
                textArea.setText("");
            }
        });
        btnGenerate.addActionListener(new ActionListener()
        {

            @Override
            public void actionPerformed(ActionEvent e)
            {
                // 1.在 tmp 下生成 application 目录，其下有三个子目录 app precompiled public
                // 存在则删除并重新创建
                String app = "application";
                String tmpPath = System.getenv("tmp");
                File applicationFile = new File(tmpPath + "/" + app);
                if (applicationFile.exists())
                {
                    FileUtils.delFile(applicationFile.getAbsolutePath());
                    applicationFile.mkdir();

                }

                List<String> fileList = Arrays.asList(textArea.getText().split("\r\n"));
                // 2.根据拖进来的文件进行按目录分类
                for (String s : fileList)
                {
                    if (null == s || s.isEmpty())
                    {
                        continue;
                    }
                    String t = tmpPath + "/" + s.substring(s.indexOf(app), s.length());
                    File sFile = new File(s);// 源文件
                    File dFile = new File(t);// 目录文件
                    dFile.getParentFile().mkdirs();
                    FileUtils.fileChannelCopy(sFile, dFile);
                }

                // 3.分完类后打开此 tmp 路径 ，供手工打包上传，并执行自动化部署脚本
                String openCmd = "cmd /c start " + applicationFile.getAbsolutePath();
                try
                {
                    Runtime.getRuntime().exec(openCmd);
                } catch (IOException ex)
                {
                    ex.printStackTrace();
                }

            }
        });

    }
}
