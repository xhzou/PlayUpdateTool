package com.pp100.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import com.pp100.frame.DropDragFrame;
import com.pp100.utils.PropertiesUtil;

/**
 * @author xhzou
 * @version 2.0
 * @created 2015年10月25日 下午5:41:02
 */
public class PlayUpdateTool {
    public static void main(String[] args) throws IOException {
        if (args.length > 0 && "cmd".equalsIgnoreCase(args[0])) 
        {
             DropDragFrame frame = new DropDragFrame(true);
             frame.setVisible(false);
        }
        else {
             DropDragFrame frame = new DropDragFrame();
             frame.setVisible(true);
        }
    }
    
    
}

