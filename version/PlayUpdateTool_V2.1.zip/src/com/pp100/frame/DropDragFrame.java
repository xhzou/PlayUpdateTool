package com.pp100.frame;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import com.pp100.utils.FileUtils;
import com.pp100.utils.PropertiesUtil;

/**
 * @author xhzou
 * @version 2.0
 * @created 2015年10月25日 下午4:00:53
 */
public class DropDragFrame extends JFrame
{
    private static final long serialVersionUID = 1L;
//    private JButton btnClear = new JButton("C 清空列表");
    private JButton btnGenerate = new JButton("G 生成更新包");
    private JTextField txtCodePath=new JTextField();
    private JTextField txtPrecompiledPath=new JTextField();
    private JTextArea areaFileList = new JTextArea();
    private JTextArea areaLogInfo = new JTextArea();

    public DropDragFrame()
    {
        initFrameInfo();
        initControl();
        initConfValue();
        bindEvent();
        
    }
    
    private void initConfValue()
    {
//         txtCodePath.setText("D:/develop/workspace/framework_play/framework_play");
        txtCodePath.setText(PropertiesUtil.getProperties("code_path", "D:/code/p2p"));
        txtPrecompiledPath.setText(PropertiesUtil.getProperties("play_path", "D:/code/p2p/trunk/code/sp2p_deploy/WEB-INF/application"));
    }
    
    /**
     * 初始化控件信息
     * 
     * @author xhzou
     * @version 1.0
     * @created 2015年10月25日 下午5:42:38
     */
    private void initControl()
    {
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBorder(BorderFactory.createTitledBorder("文件列表"));
        scrollPane.setViewportView(areaFileList);
        areaFileList.setColumns(70);
        areaFileList.setRows(16);
        
        areaLogInfo.setColumns(70);
        areaLogInfo.setRows(8);
        areaLogInfo.setEditable(false);
//        textArea.setEditable(false);

//        btnClear.setMnemonic('C');
        btnGenerate.setMnemonic('G');

        txtCodePath.setPreferredSize(new Dimension(250,20));
        txtPrecompiledPath.setPreferredSize(new Dimension(350,20));
        txtCodePath.setText("D:/code/p2p");  //设置默认值
        txtPrecompiledPath.setText("D:/code/p2p/trunk/code/sp2p_deploy/WEB-INF/application");//设置默认值
        
        JPanel panel = new JPanel();
        
        panel.add(new JLabel("代码路径："));
        panel.add(txtCodePath);
        panel.add(new JLabel("预编译路径："));
        panel.add(txtPrecompiledPath);
        
        
        JPanel panelLog = new JPanel();
        panelLog.setBorder(BorderFactory.createTitledBorder("日志信息"));
        panelLog.add(areaLogInfo);
        
        
        panel.add(scrollPane);
//        panel.add(btnClear);
        panel.add(panelLog);
        panel.add(btnGenerate);
        

        this.add(panel);
    }

    /**
     * 初始化窗体信息
     * 
     * @author xhzou
     * @version 1.0
     * @created 2015年10月25日 下午5:42:29
     */
    private void initFrameInfo()
    {
        this.setTitle("Play 局部更新包生成器 V2.0 by 邹小辉");
        this.setSize(800, 600);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        try
        {
            this.setIconImage(ImageIO.read(this.getClass().getResource("/images/icon.png")));
        } catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    /**
     * 绑定按钮事件
     * 
     * @author xhzou
     * @version 1.0
     * @created 2015年10月25日 下午5:42:16
     */
    private void bindEvent()
    {
//        btnClear.addActionListener(new ActionListener()
//        {
//
//            @Override
//            public void actionPerformed(ActionEvent e)
//            {
//                textArea.setText("");
//            }
//        });
        btnGenerate.addActionListener(new ActionListener()
        {

            @Override
            public void actionPerformed(ActionEvent e)
            {
                 createVersionFile();
            }
        });

    }

    private void createVersionFile()
    {
        // 1.在 tmp 下生成 application 目录，其下有三个子目录 app precompiled public
        // 存在则删除并重新创建
        String appPath = "application";
        String tmpPath = System.getenv("tmp");
        File applicationFile = new File(tmpPath + "/" + appPath);
        if (applicationFile.exists())
        {
            FileUtils.delFile(applicationFile.getAbsolutePath());
            applicationFile.mkdir();

        }

        String codePath = txtCodePath.getText().trim();
        String precompiledPath = txtPrecompiledPath.getText().trim();
        StringBuffer bufLog=new StringBuffer();

         List<String> lstFiles = Arrays.asList(areaFileList.getText().split("\n"));
        // 2.根据拖进来的文件进行按目录分类
        for (String strFile : lstFiles)
        {
            strFile = strFile.trim();// 去除左右空格
            if (null == strFile || strFile.isEmpty())
            {
                continue;
            }
            

            File codeFile = new File(codePath + strFile);// 代码源文件
            if (!codeFile.exists())
            {
                bufLog.append(" source file not exists... " + strFile);
                continue;
            }

            String strViews = "/app/views";
            String strApp = "/app/";
            String strPublic = "/public";
            String strConf = "/conf";
            String path = precompiledPath;
            if (strFile.contains(strViews))
            {
                path += "/precompiled/templates/" + strFile.substring(strFile.indexOf(strViews), strFile.length());
            } else if (strFile.contains(strApp))
            {
                path += "/precompiled/java/" + strFile.substring(strFile.indexOf(strApp) + strApp.length(), strFile.length());
                path = path.replace(".java", ".class");
            } else if (strFile.contains(strPublic))
            {
                path += strFile.substring(strFile.indexOf(strPublic), strFile.length());
            } else if (strFile.contains(strConf))
            {
                path += strFile.substring(strFile.indexOf(strConf), strFile.length());
            } else
            {
                bufLog.append(" source file not support... " + strFile);
                continue;
            }

            // 复制预编译后的文件
            String targetPath = tmpPath + "/" + path.substring(path.indexOf(appPath), path.length());
            File sFile = new File(path);// 预编译源文件
            if (!sFile.exists())
            {
                bufLog.append(" precompiled file not exists... " + strFile);
                continue;
            }

            File dFile = new File(targetPath);// 目标文件
            dFile.getParentFile().mkdirs();
            FileUtils.fileChannelCopy(sFile, dFile);
            //检测是否存在内部类的 class 文件
            File[] subClass=sFile.getParentFile().listFiles();
            for(File f:subClass){
                if(f.getName().contains(sFile.getName().replace(".class", "")+"$")){
                    FileUtils.fileChannelCopy(f, new File(dFile.getParent()+"/"+f.getName()));
                }
            }

            // 复制java 或 html 源文件，只需要生成文件即可(java 或 html 文件)
            if (strFile.contains(strApp))
            {
                String t = tmpPath + "/" + appPath + strFile.substring(strFile.indexOf(strApp), strFile.length());
                File file = new File(t);// 目标文件
                file.getParentFile().mkdirs();
                try
                {
                    file.createNewFile();
                } catch (IOException e)
                {
                    bufLog.append(e);
                }
            }

        }
        
        areaLogInfo.setText(bufLog.toString());

        // 3.分完类后打开此 tmp 路径 ，供手工打包上传，并执行自动化部署脚本
        String openCmd = "cmd /c start " + applicationFile.getAbsolutePath();
        try
        {
            Runtime.getRuntime().exec(openCmd);
        } catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }

    // public static void main(String[] args)
    // {
    // createVersionFile();
    // }
}
